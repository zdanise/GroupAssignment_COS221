// Cart Array to store selected wines
function clearTable(){
    var table = document.getElementById("allCarsTable");
    if(table.rows.length > 0){
        for(var i = 1; i < table.rows.length; i++){
            table.deleteRow(i);
        }
    }
}


//USER INPUT
const phone = document.getElementById("phone").value;
const address = document.getElementById("address").value;

if(phone = "" || address == ""){
    console.log("Please provide all required information");    
}
else{



    const formData = {
       
        phone: phone,
        address: address,
      
      };
      
      const requestOptions = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      };



    //LOAD ALL CART ITEMS FROM THE DATABASE
    function loadWines(){
        clearTable();   //clear table before adding new items in cart
        var table = document.getElementById("cartTable");
        var values;
        const req = new XMLHttpRequest();
        req.open("POST", "http://localhost/CARTupdated.php", true);
        req.setRequestHeader("Content-Type", "application/json; charset=UTF-8");
        const body = JSON.stringify({
        view: "yes",
        user_id: 1,
        });
        req.onreadystatechange = function(){values = JSON.parse(req.responseText);
            console.log(values.data);
            var table = document.getElementById("cartTable");
                for(var i = 0; i < 36; i++){
                    try{
                        table.innerHTML += "<tr><td>" + values.data[i].image + "</td><td>" + values.data[i].name + "</td><td>" + 
                        "750ml" + "</td><td>" + values.data[i].type + "</td><td>"+ values.data[i].quantity + "</td><td>"+ values.data[i].price + "</td></tr>";
                    }
                    catch(error)
                    {

                    }
                }
        }
        req.send(body);
    }
      

    // Function to add wine to the cart
    function addToCart(winesInCart) {
      // Check if the wine is already in the cart
      const existingItem = cartItems.find(item => item.id === winesInCart.id);

      if (existingItem) {
        // If the wine already exists in the cart, increase the quantity
        existingItem.quantity++;
      } else {
        // If the wine is not in the cart, add it as a new item
        cartItems.push({
          id: winesInCart.id,
          name: winesInCart.name,
          price: winesInCart.price,
          type: winesInCart.type,
          quantity: winesInCart.id
        });
      }

      // Add animation or visual feedback here (e.g., fade-in effect)

      // Update the cart display
      loadWines();
    }

    // Function to remove a wine item from the cart
    $(document).ready(function() {
      // Click event handler for remove buttons
      $('.remove-btn').click(function() {
        // Get the closest <tr> ancestor element of the clicked button
        var row = $(this).closest('tr');
        row.remove();
      });
    });



    // Function to calculate the subtotal of the cart
    function calculateSubtotal() {
        const subtotalTag = document.getElementById("subtotal");
      let subtotal = 0;


      for (const item of cartItems) {
        subtotal += item.price * item.quantity;
      }

      subtotalTag.innerHTML = subtotal; //DISPLAY
      return subtotal;
    }



      // Calculate and display the subtotal
      const subtotal = calculateSubtotal();
      subtotalContainer.textContent = `Subtotal: R${subtotal}`;
}    
                                                                                                                                                                                                            